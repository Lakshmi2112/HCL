package assign;

import java.util.Scanner;

public class Main {
public static void main(String args[]) {
	Square sq= new Square();
	Rectangle r = new Rectangle();
	
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter Breadth & Length of the Rectangle");
	double b= sc.nextDouble();
	double l= sc.nextDouble();
	System.out.println("Enter side value");
	int s=sc.nextInt();
	double perimeter=( 2*(l+b));
	double Area = (l*b);
	double perimeter1= (4*s);
	double Area1= (s*s);
	System.out.println("Perimeter of the Rectangle" +perimeter);
	System.out.println("Area of the Rectangle" +Area);
	System.out.println("Perimeter of the Square" +perimeter1);
	System.out.println("Area of the Rectangle" +Area1);
}
}


