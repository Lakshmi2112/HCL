package assign;

public class Square {
	double side;
public double getSide() {
		return side;
	}
	public void setSide(double side) {
		this.side = side;
	}
double calcPeri() {
	return 0;
}
double calcArea() {
	return 0;
}
}
