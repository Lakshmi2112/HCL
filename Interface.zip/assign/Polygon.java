package assign;

public interface Polygon {
abstract double calcPeri();
abstract double calcArea();
}

