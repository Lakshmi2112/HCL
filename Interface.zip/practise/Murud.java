package practise;

public class Murud {
void distance() {
	
}
}
