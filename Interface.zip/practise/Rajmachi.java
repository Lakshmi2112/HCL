package practise;

public class Rajmachi {
 void distance() {
	 
 }
}

