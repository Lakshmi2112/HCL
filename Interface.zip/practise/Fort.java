package practise;

public interface Fort {
public void distance();
}
