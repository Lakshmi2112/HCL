package practise;

public class Shivgadh {
void distance() {
}
}
