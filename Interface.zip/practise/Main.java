package practise;

import java.util.Scanner;

public class Main {
	public static void main(String args[]) {
Scanner sc= new Scanner (System.in);

Rajmachi rm= new Rajmachi();
Shivgadh sg= new Shivgadh();
Murud m= new Murud();
System.out.println("What you want to choose");

System.out.println("Rajmachi");
System.out.println("Shivgadh");
System.out.println("Murud");
String st= sc.nextLine();
if(st.equals("Rajmachi")) {
	
	System.out.println(" You are going to Visit " +st );
	System.out.println(" The distance is 55Km ");
}
else if (st.equals("Shivgadh")) {
	System.out.println(" You are going to Visit " +st );
	System.out.println(" The distance is 100Km ");
}
	

else if (st.equals("Murud")) {
	System.out.println(" You are going to Visit " +st );
	System.out.println(" The distance is 93Km ");
}
	

else
{
	System.out.println("Invalid place");
}

}
}
