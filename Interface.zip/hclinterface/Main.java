package com.hclinterface;

import java.util.Scanner;



public class Main {
	public static void main(String args[]) {
		Square sq= new Square();
		Rectangle r = new Rectangle();
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Breadth & Length of the Rectangle");
		double b= sc.nextDouble();
		r.setLength(b);
		double l= sc.nextDouble();
		r.setBreadth(l);
		System.out.println("Enter side value");
		double s=sc.nextInt();
		sq.setSide(s);
		
		r.calcPeri();
		
		r.calcArea();
		
		sq.calcPeri();
		sq.calcArea();
		
}
}
