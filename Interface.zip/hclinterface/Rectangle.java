package com.hclinterface;




	public class Rectangle implements Polygon{
		double length;
		double breadth;
		public Rectangle(double length, double breadth) {
			super();
			this.length = length;
			this.breadth = breadth;
		}
		public Rectangle() {
			// TODO Auto-generated constructor stub
		}
		public double getLength() {
			return length;
		}
		public void setLength(double length) {
			this.length = length;
		}
	
		public double getBreadth() {
			return breadth;
		}
		public void setBreadth(double breadth) {
			this.breadth = breadth;
		}
		public void calcPeri() {
			double p= 2*(length+breadth);
			System.out.println("Perimeter of the Rectangle" +p);
			
		}
		public void calcArea() {
			double A = length*breadth;
			System.out.println("Area of the Rectangle" +A);
			

		}
	
}
	
	
	
