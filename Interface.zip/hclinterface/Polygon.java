package com.hclinterface;

public interface Polygon {
	abstract void calcPeri();
	abstract void calcArea();
	}

