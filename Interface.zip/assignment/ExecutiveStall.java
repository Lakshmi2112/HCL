package assignment;

public class ExecutiveStall implements Stall {
	private String stallName;
	private int cost;
	private String ownerName;
	private int screen;
	public ExecutiveStall() {
		
	}
	
	public ExecutiveStall(String stallName, int cost, int screen) {
		super();
		this.stallName = stallName;
		this.cost = cost;
		this.screen = screen;
	}


	public String getStallName() {
		return stallName;
	}

	public void setStallName(String stallName) {
		this.stallName = stallName;
	}

	public int getCost() {
		return cost;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public int getScreen() {
		return screen;
	}

	public void setScreen(int screen) {
		this.screen = screen;
	}

	@Override
	public void display() {
		
		System.out.println("Stall Name:" +getStallName() );
		System.out.println("Cost:" +getCost() );
		System.out.println("Owner name:" +getOwnerName() );
		System.out.println("Number of Screens:" +getScreen() );
	}

	
	

	
}
