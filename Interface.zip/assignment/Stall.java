package assignment;

public interface Stall {
void display() ;
	

}
