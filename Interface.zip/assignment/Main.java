package assignment;

import java.util.Scanner;

public class Main {
public static void main(String args[]) {
	
	
	
	Scanner sc= new Scanner(System.in);
	System.out.println("Choose stall type");
	System.out.println("1) Gold Stall");
	System.out.println("2) Premium Stall");
	System.out.println("3) Executive Stall");
	int choice= sc.nextInt();
	
	if (choice==1) {
		
		System.out.println("Enter Stall details in comma separated(Stall Name,Stall Cost,Owner name,Number of TV sets)");
		sc.nextLine();
		String st=sc.nextLine(); 
	
		String[]str= st.split(",");
		GoldStall gs=new GoldStall();
		gs.setStallName(str[0]);
		gs.setCost(Integer.parseInt(str[1]));
		gs.setOwnerName(str[2]);
		gs.setTvSet(Integer.parseInt(str[3]));
		gs.display();
		
		
	}
	else if (choice ==2) {
		System.out.println("Enter Stall details in comma separated(Stall Name,Stall Cost,Owner name,Number of Projectors)");
		sc.nextLine();
		String st1=sc.nextLine();
		String[]str= st1.split(",");
		PremiumStall ps= new PremiumStall();
		ps.setStallName(str[0]);
		ps.setCost(Integer.parseInt(str[1]));
		ps.setOwnerName(str[2]);
		ps.setProjector(Integer.parseInt(str[3]));
		ps.display();
		
		
		
	}
	else if(choice==3) {
		System.out.println("Enter Stall details in comma separated(Stall Name,Stall Cost,Owner name,Number of Screens)");
		sc.nextLine();
		String st2=sc.nextLine();
		String[]str= st2.split(",");
	
		ExecutiveStall es = new ExecutiveStall();
		es.setStallName(str[0]);
		es.setCost(Integer.parseInt(str[1]));
		es.setOwnerName(str[2]);
		es.setScreen(Integer.parseInt(str[3]));
		es.display();
		
		
		
	}
	else
		System.out.println("Invalid choice");
}
}
