package assignment1;

public interface Car {
public void sum(int sum);
public void years(double years);
public void brand(String brand);
}
