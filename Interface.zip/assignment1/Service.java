package assignment1;
public  class Service implements Car {

	public void sum(int n) {
		 int sum = 0; 
		 int remainder = 0;
         
	     
			while (n != 0) 
	        { 
	            sum = sum + remainder % 10; 
	            remainder = remainder/10; 
	            n=n/10;
	        } 
	     // return; 
       if(sum % 2 == 0)
        {
            System.out.println("You can come on Tuesday,Thursday,Saturdy");
            
        }
        else
        {
            System.out.println("You can come Monday,Wednesday,Friday");
	}
}





@Override
public void years(double years) {
	
	if(years>5) {
		System.out.println("You are eligible for free washing");
	}
	else
		System.out.println("You are not eligible for free washinhg");
}
	


@Override
public void brand(String brand) {
	//double charge=0;
if(brand.equals ("Maruti"))
{
		
double	charge=5000-(5000*0.05);
	 System.out.println("Your service Charges" +charge);
		}
else
		 System.out.println("There is no discount in your service" +5000);
	
}
}





