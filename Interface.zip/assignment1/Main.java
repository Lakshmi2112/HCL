package assignment1;

import java.util.Scanner;

public class Main {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	Service s=new Service();
	System.out.println("Enter your Car number");
	int num=sc.nextInt();
	System.out.println("How many years card do you have");
	int years=sc.nextInt();
	sc.nextLine();
	System.out.println("Enter your Car brand");
	String brand=sc.nextLine();
   
	s.sum(num);
	s.years(years);
	s.brand( brand);
	
}

}
