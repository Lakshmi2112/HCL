package hcl;

public class ICICI implements MutualFund {

	@Override
	public void duration() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void amount() {
		// TODO Auto-generated method stub
		
	}

}
