package hcl;

import java.util.Scanner;

public class AxisBank implements MutualFund{

	@Override
	public void duration() {
		
	}
	

	@Override
	public void amount() {
	
}
}