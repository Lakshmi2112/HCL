package hcl;

import java.util.Scanner;

public class Main {
public static void main(String args[]) {
	Scanner sc= new Scanner (System.in);
	AxisBank ab= new AxisBank();
	HDFC hdfc = new HDFC();
	ICICI icici= new ICICI();
	System.out.println("Choose the Bank");
	System.out.println("Axis Bank");
	System.out.println("HDFC");
	System.out.println("ICICI");
	String st= sc.nextLine();

	if(st.equals("AxisBank")) {
		
		System.out.println("Enter the amount you want to invest");
		double amt=sc.nextInt();
		System.out.println("Enter the Tenure of the SIP");
		int y= sc.nextInt();
		double returnMoney= (amt * y * 0.56);
		System.out.println("YOU WILL HAVE RETURNS AS " +returnMoney +" in " +y +" years " );
		ab.duration();
		ab.amount();
	}
	else if (st.equals("HDFC")){
		
		System.out.println("Enter the amount you want to invest");
		double amt=sc.nextInt();
		System.out.println("Enter the Tenure of the SIP");
		int y= sc.nextInt();
		double returnMoney= (amt * y * 0.49);
		System.out.println("YOU WILL HAVE RETURNS AS " +returnMoney +" in " +y +" years " );
		hdfc.duration();
		hdfc.amount();
		
	}
	else if (st.equals("ICICI")){
		
		System.out.println("Enter the amount you want to invest");
		double amt=sc.nextInt();
		System.out.println("Enter the Tenure of the SIP");
		int y= sc.nextInt();
		double returnMoney= (amt * y * 0.60);
		System.out.println("YOU WILL HAVE RETURNS AS " +returnMoney +" in " +y +" years " );
		icici.duration();
		icici.amount();
	}
	else {
		System.out.println("Invalid bank");
	}
}
}
