package hcl;

public interface MutualFund {
abstract public void duration();
abstract public void amount();

}
