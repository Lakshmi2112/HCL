package strings;

import java.util.Scanner;

public class stringBuilder {
	public static void main(String args[]) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Humpty's sentence: ");
		StringBuffer sb= new StringBuffer(sc.nextLine());
		System.out.println("Humpty says : " +sb);
		System.out.println("What Dumpty want to insert and where? ");
		String insert= new String(sc.nextLine());
		System.out.println("Enter position");
		int position = sc.nextInt();
		
	    sb= sb.insert(position-1,insert);

		System.out.println(" Humpty new sentence:  " +sb);
}
}
