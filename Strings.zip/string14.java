package strings;

import java.util.Scanner;

public class string14 {

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter to be camelled ");
		String s = sc.nextLine();
		
		String[] words = s.split(" ");
		int now = words.length;
		
		for(int i=0;i<now;i++)
		{
			System.out.print(Capitalize(words[i]));
		}
	}
	public static String Capitalize(String w) {
		if(w.charAt(0) > 97)
		{
			char s = (char)(w.charAt(0) - 32);
			return new String(s + w.substring(1, w.length()));
		}
		else
		{
			return w;
		}
	}
}
