package strings;

import java.util.Scanner;

public class string9 {
	public static void main(String args[]) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Humpty's sentence: ");
		String s= new String(sc.nextLine());
		 String finalString = s.toUpperCase();
		System.out.println("Converted String: " +finalString);
}


}