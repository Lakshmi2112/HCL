package strings;

import java.util.Scanner;

public class string1 {
public static void main(String args[]) {
	Scanner sc= new Scanner(System.in);
	System.out.println(" Enter Humpty's Sentence : ");
	String s= new String (sc.nextLine());
	s=s.concat(".");
	System.out.println(" Enter Dumpty's Sentence : ");
	s= s.concat(sc.nextLine());
	System.out.println(" Concatenated String : " +s);
	sc.nextLine();
	
	}
}
