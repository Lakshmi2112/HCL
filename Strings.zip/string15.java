package strings;
import java.util.Scanner;
public class string15 {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of users:");
		int n = sc.nextInt();
		
		sc.nextLine();
		
		String[] oA = new String[n];
		System.out.println("Enter user address details in CSV format(User,ID, Street, City, State)");
		for(int i=0;i<n;i++)
		{
			String line = sc.nextLine();
			String[] words = line.split(",");
			oA[i] = String.format("%-15s %-15s %-15s %s\n", words[0], words[1], words[2],words[3]);
			
		}
		System.out.println(String.format("%-15s %-15s %-15s %s", "User ID", "Street", "City", "State"));
		for(int i=0;i<n;i++)
			System.out.print(oA[i]);
	}
}


