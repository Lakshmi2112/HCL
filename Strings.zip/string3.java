package strings;

import java.util.Scanner;

public class string3 {
	public static void main(String args[]) {
		Scanner sc= new Scanner(System.in);
		System.out.println(" Enter Humpty's Sentence : ");
		String s= new String(sc.nextLine());
		System.out.println(" Enter word to replace : ");
		String r= sc.nextLine();
		System.out.println(" Synonym: ");
		String synonym= sc.nextLine();
		if(s.indexOf(r)!=-1) {
			String finalWord =s.replace(r,synonym );
			System.out.println("Replaced String : " +finalWord );
			
		}
		else
			System.out.println("There is no such word");
		
		
		
	}
	
}