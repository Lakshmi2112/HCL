package strings;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class string12 {
	public static void main(String args[]) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the email address:");
		String s= new String(sc.nextLine());
		
		int pos = s.indexOf('.');
		
		String on = s.substring(pos + 1, s.length());
		
		if(on.equals("com") || on.equals("in") || on.equals("net") || on.equals("org"))
			System.out.println("Valid email address");
		else
			System.out.println("Invalid email address");
	}
		
}


