package strings;

import java.util.Scanner;

public class string10 {
	public static void main(String args[]) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Humpty's sentence: ");
		String s= new String(sc.nextLine());
		String finalString =s.toUpperCase();
		if(s.equals(finalString)) {
		System.out.println("String is in uppercase");
		}
		else {
			System.out.println("String is not in uppercase");
		}
}
}