package strings;

import java.util.Scanner;

public class stringBuffer {
	public static void main(String args[]) {
		Scanner sc= new Scanner(System.in);
		System.out.println(" Enter Humpty's Sentence : ");
		StringBuffer sb= new StringBuffer (sc.nextLine());
		StringBuffer word  = sb.reverse();
		System.out.println(" Dumpty says : " +word );
}
}