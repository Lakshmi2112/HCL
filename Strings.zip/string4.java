package strings;

import java.util.Scanner;

public class string4 {
	public static void main(String args[]) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Dumpty says : ");
		String s= new String(sc.nextLine());
		System.out.println(" What Humpty want to remove : ");
		String r= sc.nextLine();
		String finalWord=s.replace(r,"");
		System.out.println(finalWord);
}
}