package strings;

import java.util.Scanner;

public class string11 {
	public static void main(String args[]) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Address 1 :");
		String s= new String(sc.nextLine());
		System.out.println("Address 2 :");
		String s1= new String(sc.nextLine());		
			
		if(s.length() != s1.length())
		{
			int l1 = 0;
			int l2 = 0;
			for(int i=0;i<s.length();i++)
			{
				if(s.charAt(i)!=' ')
					l1++;
			}
			for(int i=0;i<s1.length();i++)
			{
				if(s1.charAt(i)!= ' ')
					l2++;
			}
			
			char cs1[] = new char[l1];
			char cs2[] = new char[l2];
			
		
			
			for(int i=0;i<s.length();i++)
			{
				int j =0;
				if(s.charAt(i) != ' ')
				{	cs1[j++] = s.charAt(i); }
			}
			for(int i=0;i<s1.length();i++)
			{
				int j =0;
				if(s1.charAt(i) != ' ') {
					cs2[j++] = s1.charAt(i);}
			}		
			
			if((new String(cs1)).contentEquals(new String(cs2)))
			{	
				System.out.println(" YELLOW ");
				return;
			}
		}
		
		if(s.equals(s1)) {
			System.out.println(" RED ");
		}
		else if(s.equalsIgnoreCase(s1)) {
			System.out.println(" BLUE ");
		}
		else {
			System.out.println(" GREEN ");
		}
    }
}


