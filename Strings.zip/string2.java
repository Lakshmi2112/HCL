package strings;

import java.util.Scanner;

public class string2 {
	public static void main(String args[]) {
		Scanner sc= new Scanner(System.in);
		System.out.println(" Enter Humpty's Sentence : ");
		String s= new String (sc.nextLine());
		System.out.println(" Enter Dumpty's word : ");
		String d =sc.nextLine();
		if ( s.indexOf(d)!= -1 ) {
			System.out.println( "Found the word " +d);
		}
		else {
			System.out.println(" Cant find " +d);
		}
}
}
