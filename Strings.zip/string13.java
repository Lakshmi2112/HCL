package strings;

import java.util.Scanner;

public class string13 {
	public static void main(String args[]) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the date Value:");
		int d = sc.nextInt();
		
		System.out.println("Date Correct format:");
		int d1 = sc.nextInt();
		
		
	}
}
