package strings;

import java.util.Scanner;

public class string8 {
	public static void main(String args[]) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Humpty's sentence: ");
		StringBuffer sb= new StringBuffer(sc.nextLine());
		System.out.println("Enter Dumpty's sentence: ");
		StringBuffer sb1= new StringBuffer(sc.nextLine());
		int count =sb.length();
		int count1 = sb1.length();
		if(count>count1) {
			System.out.println("Humpty has used more words");
		}
		else if(count<count1) {
			System.out.println("Dumpty has used more words");
		}
		else {
			System.out.println("Both have used equal number of words");
		}
				
}
}