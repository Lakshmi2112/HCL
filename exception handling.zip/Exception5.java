package com.hcl;

import java.util.Scanner;

public class Exception5 {
public static void main(String args[]) throws ArithmeticException {
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the cost of the item for n days");
	int cost = sc.nextInt();
	System.out.println("Enter the value of n");
	int n = sc.nextInt();
	divide(cost,n);
}
public static void  divide(int cost, int n) throws ArithmeticException{
	try {
		if(n==0) {
			throw new ArithmeticException ();
			
		}
		else {
			System.out.println("Cost per day of the item is " +cost/n);
		}
	}
	

catch (ArithmeticException ae) {
	System.out.println("Arithemetic Exception by Zero" );
}
	
}
}