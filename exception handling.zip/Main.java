package com.hcl;

import java.util.Scanner;

public class Main {
public static void main(String args[]) {
	int []arr=new int[10];
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter any 10 values");
	for(int i=0;i<10;i++) {
		arr[i]=sc.nextInt();
		}
try {
	for(int i=10,j=0;i>=0;i--,j++) {

	System.out.println("Result:" +arr[j]/i);
	
	}
	
}
catch (IndexOutOfBoundsException e){
    System.out.println("Elements Over");
	}

}
}
