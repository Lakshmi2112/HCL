package com.hcl;

import java.util.Scanner;

public class Vicky {
public static void main(String args[]) {
	int []arr=new int[10];
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter any 10 values");
	for(int i=0;i<10;i++) {
		arr[i]=sc.nextInt();
		}
	System.out.println("Enter the divisor");
	int divisor= sc.nextInt();
	try {
		for(int i=0;i<10;i++) {

		System.out.println("Result:" +arr[i]/divisor);
		
		}
		
	}

	catch(ArithmeticException ae) {
		System.out.println("Cannot divide by zero");
	}

	}
	}


