package com.hcl;

import java.io.IOException;
import java.util.Scanner;

public class ItemType {
	private	 String name;
	private  Double deposit;
	private  Double costPerday;
	public ItemType() {
		
	}
	public ItemType(String name, Double deposit, Double costPerday) {
		super();
		this.name = name;
		this.deposit = deposit;
		this.costPerday = costPerday;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getDeposit() {
		return deposit;
	}
	public void setDeposit(Double deposit) {
		this.deposit = deposit;
	}
	public Double getCostPerday() {
		return costPerday;
	}
	public void setCostPerday(Double costPerday) {
		this.costPerday = costPerday;
	}
	public static void main(String args[])throws IOException {
	Scanner sc= new Scanner(System.in);
	ItemType it = new ItemType();
	System.out.println("Enter the Item type details:");
	System.out.println("Enter the name : ");
	it.setName(sc.nextLine());
	try {

	System.out.println("Enter the deposit :");
	it.setDeposit(Double.parseDouble(sc.nextLine()));
	System.out.println("Enter the cost per day :");
	it.setCostPerday(Double.parseDouble(sc.nextLine()));
	System.out.println("The details of the item type are:");
	System.out.println("Name : " +it.getName() );
	System.out.println("Deposit :" +it.getDeposit());
	System.out.println("Cost per day :" +it.getCostPerday());
	
        }
catch (NumberFormatException nfe) {
	System.out.println("For Input String : "+ nfe.toString());
	}
}
}



