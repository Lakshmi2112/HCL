package com.hcl;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Exception6 {
	public static void main(String args[]) {
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter an integer input :");
	int input = sc.nextInt();
	try {
	if(input== (int ) input){
		System.out.println("Entered value is " +input);
	}
	else {
		
	}
}
catch(InputMismatchException ime) {
	//System.out.println("InputMismatchException");
}
}
}

