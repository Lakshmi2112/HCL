package com.hcl;

import java.util.Scanner;

public class IllegalArgumentException extends Exception {

public static void main(String args[]) throws IllegalArgumentException {
	int []arr=new int[10];
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter any 10 values");
for(int i=0;i<10;i++) {
	arr[i]=sc.nextInt();
	}
System.out.println("Enter the divisor");
int divisor= sc.nextInt();
for(int i=0;i<10;i++) {
	divide(arr[i],divisor);
}
}
	private static void divide(int a, int divisor) throws IllegalArgumentException{
	try {
		if((divisor%2==0)&& (a%2 !=0)) {
			throw new IllegalArgumentException();
		}
		else if((divisor%2!=0)&& (a%2 ==0)) {
			throw new IllegalArgumentException();
		}
		else
		{
			System.out.println("Result: " +a/divisor);
	}
}
catch(IllegalArgumentException e){
	System.out.println("Exception handled in method" );
	System.out.println("Result: " +a/divisor);
		
	}
		
	}

}




