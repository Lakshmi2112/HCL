package com.or2;

import java.util.Scanner;

public class Main {


	
	static int numberOfProduct = 5;

	public static void main(String[] args){
		
		Product[] arr = new Product[numberOfProduct];
		
		for(int j=0;j<numberOfProduct;j++)
		{
			Product p = buildProduct();
			arr[j]= p;
		}
		
		System.out.println("Product details: ");
		
		for(int j=0;j<numberOfProduct;j++) {
			
			System.out.println();
			System.out.println(Product.getName());
			System.out.println("Product Code: "+arr[j].getProduct_code());
			System.out.println("Name: "+arr[j].getProduct_name());
			System.out.println("Stock: "+arr[j].getStock());
			System.out.println("Price: "+arr[j].getPrice());
			System.out.println("Discounted Price: "+arr[j].getDiscountedPrice(arr[j]));
			
		}
		
		System.out.println();
		System.out.println(Product.checkPrice(arr));
		
		Product a = Product.checkLessStock(arr);
		System.out.println();
		System.out.println("The Product wih min stock: ");
		System.out.println();
		System.out.println(Product.getName());
		System.out.println("Name: "+a.getProduct_name()+"\n"+"Stock: "+a.getStock());
		
	}
	
	
	private static Product buildProduct() {
		
		Product p1 =new Product();
		Scanner sc = new Scanner(System.in);
		Product.setName("L & K Suppliers");
		System.out.println("Enter Product Code: ");
		p1.setProduct_code(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter Product Name: ");
		p1.setProduct_name(sc.nextLine());
		System.out.println("Enter Price: ");
		p1.setPrice(sc.nextDouble());
		System.out.println("Enter Stock: ");
		p1.setStock(sc.nextInt());
		System.out.println();			
		return p1;		
	}

}

