package com.hcl5;

public class Exhibition extends Event {
private int noOfStall;

/*public Exhibition(String name, String detail, String ownerName, int noOfStall) {
	super(name, detail, ownerName);
	this.noOfStall = noOfStall;*/

public Exhibition() {
	
}

public Exhibition(int noOfStalls) {
	this.noOfStall = noOfStall;
}



public int getNoOfStall() {
	return noOfStall;
}

public void setNoOfStall(int noOfStall) {
	this.noOfStall = noOfStall;
}




public double getProjectedRevenue(double noOfStalls) {
	double revenue= noOfStalls *10000 ;
	return revenue;
}

public void setProjectedRevenue(int noOfStalls) {
	// TODO Auto-generated method stub
	
}




}
