package com.hcl5;

public class StageEvent extends Event{
	protected int noOfShows;
	protected int noOfSeatsPerShow	;
	
	public StageEvent(String name, String detail, String ownerName, int noOfShows, int noOfSeatsPerShow) {
		super(name, detail, ownerName);
		this.noOfShows = noOfShows;
		this.noOfSeatsPerShow = noOfSeatsPerShow;
	}
	public StageEvent(int noOfShows2) {
		// TODO Auto-generated constructor stub
	}
	public int getNoOfShows() {
		return noOfShows;
	}
	public void StageEvent1(String name, String detail, String ownerName, int noOfShows, int noOfSeatsPerShow) {
		//super (name, detail, ownerName);
		this.noOfShows = noOfShows;
		this.noOfSeatsPerShow = noOfSeatsPerShow;
	}
	public void setNoOfShows(int noOfShows) {
		this.noOfShows = noOfShows;
	}
	public int getNoOfSeatsPerShow() {
		return noOfSeatsPerShow;
	}
	public void setNoOfSeatsPerShow(int noOfSeatsPerShow) {
		this.noOfSeatsPerShow = noOfSeatsPerShow;
	}
	
	public double getProjectedRevenue(double noOfShows, double noOfSeatsPerShow) {
		double revenue= (noOfShows * noOfSeatsPerShow*50);
		return revenue;
	}
	public void setProjectedRevenue(int noOfShows2) {
		// TODO Auto-generated method stub
		
	}
	public void setProjectedRevenue(int noOfShows2, int noOfSeatsPerShow2) {
		// TODO Auto-generated method stub
		
	}
}
