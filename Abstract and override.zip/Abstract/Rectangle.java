package com.hcl7;

public class Rectangle extends Shape {
public  float length;
public float breadth;
public Rectangle(float length, float breadth) {
	super();
	this.length = length;
	this.breadth = breadth;
}

public double calculatePerimeter() {
    double perimeter= (2*(length+breadth));
	return perimeter;
}

}
