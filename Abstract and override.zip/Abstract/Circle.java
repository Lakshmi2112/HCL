package com.hcl7;

public class Circle extends Shape {
    public float radius;
    public Circle() {
	
 }
    public Circle(float radius) {
	super();
	this.radius = radius;
 }
public double calculatePerimeter() {
	Circle cr= new Circle();
	double perimeter= (2*3.14*radius);
	return perimeter;
	
 }
}
