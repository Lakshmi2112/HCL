package com.hcl7;

import java.util.Scanner;

public class Main {
	private static String perimeter;

	public static void main(String args[]) {
Scanner sc=new Scanner(System.in);
System.out.println("List of Shapes:");
System.out.println("1. Circle");
System.out.println("2.Rectangle");
System.out.println("3.Square");
System.out.println("Enter your choice");
int choice= sc.nextInt();

if(choice==1) {
	System.out.println("Enter the radius of the circle");
float radius = sc.nextFloat();
Circle cr = new Circle(radius);
 cr.calculatePerimeter();
 System.out.println("The perimeter is" +cr.calculatePerimeter() );
	 
	
}
else if (choice==2) {
	System.out.println("Enter the length of the rectangle");
float length = sc.nextFloat();
System.out.println("Enter the breadth of the rectangle");
float breadth = sc.nextFloat();
Rectangle rc = new Rectangle( length,breadth);
 rc.calculatePerimeter();
 System.out.println("The perimeter is" +rc.calculatePerimeter());
	
}
else if (choice==3) {
	System.out.println("Enter the sides of the square");
	float side = sc.nextFloat();
	
	Square sq = new Square(side);
	 sq.calculatePerimeter();
	 System.out.println("The perimeter is" +sq.calculatePerimeter() );
}
else
	System.out.println("Invalid choice");
}


	}

	
	


	

