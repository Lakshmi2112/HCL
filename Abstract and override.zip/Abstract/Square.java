package com.hcl7;

public class Square extends Shape {
public float side;

public Square(float side) {
	super();
	this.side = side;
}

public double calculatePerimeter() {
	double perimeter=4*side ;
	return perimeter;
}
}
