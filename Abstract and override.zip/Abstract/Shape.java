package com.hcl7;

public abstract class Shape {
public abstract double calculatePerimeter();

}
