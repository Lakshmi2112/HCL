package org.hcll;

public class DbConstants {
	public static final String DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String URL = "jdbc:mysql://localhost:3306/sys";
	public static final String UNAME = "root";
	public static final String PWD = "lakshmi21";
}
