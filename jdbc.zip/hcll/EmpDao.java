package org.hcll;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

public interface EmpDao {


	boolean	insert(Emp e);
	Emp get(int eno);
	List<Emp> getAll();
	boolean delete(int eno);
}