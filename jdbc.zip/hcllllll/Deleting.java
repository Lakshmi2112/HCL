package org.hcllllll;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Deleting {
public static void main(String[]args) throws ClassNotFoundException, SQLException {
	Scanner sc = new Scanner(System.in);
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection con =null;
	PreparedStatement pst=null;
	try {
		 con =DriverManager.getConnection("jdbc:mysql://localhost:3306/sys","root","lakshmi21");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	if(con != null) {
		pst=con.prepareStatement("delete from emp where eno=?");
		System.out.println("enter the eno");
		int eno=Integer.parseInt(sc.nextLine());
		pst.setInt(1, eno);
		int i=pst.executeUpdate();
		
	}
	else {
		System.out.println("Deletion unsuccessful ");
	}
}
}
