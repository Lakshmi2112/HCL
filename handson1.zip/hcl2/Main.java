package com.hcl2;

import java.util.Scanner;

public class Main {
	public static void main(String []a) {
	  Player player=new Player();
	  Scanner sc= new Scanner (System.in);
	  System.out.printf("enter the Player name");
	  String name= sc.nextLine();
	  System.out.printf("enter the Country name");
	  String country= sc.nextLine();
	  System.out.printf("enter the Skill");
	  String skill= sc.nextLine();
	  System.out.printf("Player Details : ");
	  player.setName (name);
	  player.setCountry (country);
	  player.setSkill(skill);
	  System.out.printf("\nPlayer Name : "+name);
	  System.out.printf("\nCountry Name : "+country);
	  System.out.printf("\nSkill : "+skill);
      }
}
