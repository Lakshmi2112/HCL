package com.hcl1;
import java.util.Scanner;
public class Main {
	public static void main (String []a) {
	    Venue venue= new Venue();
	    Scanner sc= new Scanner(System.in);
		System.out.println("enter the venue name");
		String venue1= sc.nextLine();
		System.out.println("enter the city name");
		String city= sc.nextLine();
	    System.out.println("Venue Details : ");
		venue.setName (venue1);
		venue.setCity (city);
		System.out.println("\nVenue Name is: "+venue1);
		System.out.println("\nVenue Details is: "+city);
	   }
}
