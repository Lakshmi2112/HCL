package com.hcl8;

import java.util.Scanner;
public class Main {
	public static void main(String []args) {
		String[]wickets=new String[10];
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number of wickets");
		int n=sc.nextInt();
		sc.nextLine();
        for(int i=1;i<=n;i++) {
		System.out.println("Enter the details of wicket " +i);
		wickets[i-1]=sc.nextLine();
		}
		System.out.println("Wicket Details" );
		for(int i=0;i<n;i++) {
			String []str= wickets[i].split(",");
		    Wicket wickets1= new Wicket(Long.parseLong (str[0]),(Long.parseLong (str[1])),(str[2]),(str[3]),(str[4]));
		    System.out.println("Over:" +wickets1.getOver() + "\n" + "Ball:" +wickets1.getBall() + "\n" + "Wicket:"+wickets1.getWicketType()+"\n"+ "Player Name: " +wickets1.getPlayerName()+"\n"+"Bowler Name: " +wickets1.getBowlerName());
	     }
      }	
}
	
		
		
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
