package com.hcl4;

import java.util.Scanner;

public class Main {
  public static void main(String []a) {
	  Player p= new Player();
	  Scanner sc= new Scanner(System.in);
	  System.out.println("enter the player details");
	  String Player=sc.nextLine();
	  String [] str=Player.split(",");
      p.setName(str[0]);
	  p.setCountry(str[1]);
	  p.setSkill(str[2]);
	  System.out.println("Player Details:" + '\n' + "Player Name:" +p.getName()+'\n' + "Country Name:" +p.getCountry()+ '\n' + "Skill:"+p.getSkill() ); 
	 
   }
}