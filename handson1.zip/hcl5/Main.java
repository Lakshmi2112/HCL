package com.hcl5;

import java.util.Scanner;

public class Main {
  public static void main(String args[]) {
	  Venue ven=new Venue();
	  Scanner sc= new Scanner(System.in);
	  System.out.println("Enter the venue name");
	  String venue=sc.nextLine();
	  System.out.println("Enter the city name");
	  String city=sc.nextLine();
	  ven.setName(venue);
	  ven.setCity(city);
	  ven.venueDetail();
	  ven.venueOption();
	  int Option;
	  do {
		  Option=sc.nextInt();
		  switch(Option) {
			case 1: 
				System.out.println("Enter the venue name");
				sc.nextLine();
				ven.setName(sc.nextLine());
				ven.venueDetail();
				ven.venueOption();
				break;
			case 2: 
				System.out.println("Enter the city name");
				sc.nextLine();
				ven.setCity(sc.nextLine());
				ven.venueDetail();
				ven.venueOption();
				break;		
			case 3: 
				ven.venueDetail();
			
		  }
	  }while(Option<=3);
  }
}
			
			
			
			
			
			
			
			
			
			
			
			
		
	
	
	  
	  
	  
	  
	
