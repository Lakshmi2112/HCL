package com.hcl5;

public class Venue {
private String name;
private String city;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public void venueDetail(){
	  System.out.println("Venue Details"+'\n');
	  System.out.println("Venue Name:" +name);
	  System.out.println("City Name:" +city);
	  System.out.println("Verify and Update venue details");
	  System.out.println("Menu");
}
public void venueOption(){	  
	  System.out.println(" 1. Update Venue Name");
	  System.out.println(" 2. Update City Name");
	  System.out.println(" 3. All informations are correct/Exit");
	  System.out.println("Type 1 or 2 or 3");
	
}

}
