package com.hcl3;

public class Delivery {
 Long over;
 Long ball;
 Long runs;
 String batsman;
 String bowler;
 String nonStriker;
void displayDeliveryDetails(){
	System.out.println("Over:" +over);
	System.out.println("Ball:" +ball);
	System.out.println("Runs:" +runs);
	System.out.println("Batsman:" +batsman);
	System.out.println("Bowler:" +bowler);
    System.out.println("NonStriker:" +nonStriker);
    }
}