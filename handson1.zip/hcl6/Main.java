package com.hcl6;

import java.util.Scanner;

public class Main {
public static void main(String []args) {
	extraType Ext= new extraType();
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the extratype details");
	String extraType =sc.nextLine();
	String []str=extraType.split("#");
	Ext.setName(str[0]);
	Ext.setRuns( (long) Integer.parseInt(str[1]));

	System.out.println("Extratype Details:"+ "\n" + "Extra Type:"+Ext.getName() + "\n"+"Runs:"+ Ext.getRuns());
	
}
}
