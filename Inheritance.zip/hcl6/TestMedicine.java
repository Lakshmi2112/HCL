package com.hcl6;

import java.util.Scanner;
import java.time.LocalDate;
import java.util.Random;
import java.time.format.*;

public class TestMedicine {	
	
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		Random rand = new Random();
		int number = 2;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
		Medicine medicines[] = new Medicine[number];
		String details;
		String[] dets;
		for(int i=0;i<medicines.length;i++)
		{
			int choice = rand.nextInt(3);
			switch(choice)
			{
				case 0: System.out.println("Enter Ointment details: ");
						details = sc.nextLine();
						dets = details.split(",");
						Ointment ointment = new Ointment(dets[0], Double.parseDouble(dets[1]), LocalDate.parse(dets[2], formatter));
						medicines[i] = ointment;
						break;
				case 1: System.out.println("Enter Syrup details: ");
						details = sc.nextLine();
						dets = details.split(",");
						Syrup syrup = new Syrup(dets[0], Double.parseDouble(dets[1]), LocalDate.parse(dets[2], formatter));
						medicines[i] = syrup;
						break;
				case 2: System.out.println("Enter Tablet details: ");
						details = sc.nextLine();
						dets = details.split(",");
						Tablet tablet = new Tablet(dets[0], Double.parseDouble(dets[1]), LocalDate.parse(dets[2], formatter));
						medicines[i] = tablet;
						break;
			}
		}
		System.out.println("----------------");
		for(int i=0;i<number;i++)
		{
			medicines[i].getDetails();
			medicines[i].displayLabel();
		}
	}
}


//
	