package com.hcl6;

import java.time.LocalDate;

public class Syrup extends Medicine{

	@Override
	public void displayLabel() {
		System.out.println("Take physician's advice\nDosage:\nAdult: 2 spoons twice a day\nChildren: 1 spoon twice a day");
		
	}

	public Syrup(String name, double price, LocalDate expirydate) {
		super(name, price, expirydate);
		// TODO Auto-generated constructor stub
	}
 
}
