package com.hcl6;

import java.time.LocalDate;

public class Tablet extends Medicine {

	@Override
	public void displayLabel() {
		System.out.println("Store in cool place");
		
	}

	public Tablet(String name, double price, LocalDate expirydate) {
		super(name, price, expirydate);
		// TODO Auto-generated constructor stub
	}

}
