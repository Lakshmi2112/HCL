package com.hcl6;

import java.time.LocalDate;

public abstract class Medicine {
	private String Name;
	private double Price;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public double getPrice() {
		return Price;
	}
	public void setPrice(double price) {
		Price = price;
	}
	public LocalDate getExpirydate() {
		return Expirydate;
	}
	public void setExpirydate(LocalDate expirydate) {
		Expirydate = expirydate;
	}
	public Medicine(String name, double price, LocalDate expirydate) {
		super();
		Name = name;
		Price = price;
		Expirydate = expirydate;
	}
	
	private LocalDate Expirydate;
	
	public void getDetails() {
		System.out.println("\n\nMedicine Details: " +
	"\nName: " + getName() + "\nPrice: " + getPrice() + "\nExpiry Date: " + getExpirydate());
	}
	public abstract void displayLabel();
	
}
