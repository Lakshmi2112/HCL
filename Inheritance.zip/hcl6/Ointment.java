package com.hcl6;

import java.time.LocalDate;

public class Ointment extends Medicine {

	public Ointment(String name, double price, LocalDate expirydate) {
		super(name, price, expirydate);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void displayLabel() {
		// TODO Auto-generated method stub
		System.out.println("For external use only");
	}

}
