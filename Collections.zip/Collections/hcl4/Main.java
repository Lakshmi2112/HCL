package collections.hcl4;

import java.util.ArrayList;
import java.util.Scanner;

public class Main extends ArrayList{
	

	public static void main(String args[]) {
		ArrayList user = new ArrayList();
		Scanner sc = new Scanner(System.in);

		User u = new User();

		user.add(new User("Aiswarya", "9476518273", "Aishu", "aishu.19@abc.in"));
		user.add(new User("Nivedha", "7654923845", "RS", "nivedha@abc.in "));
		user.add(new User("Sangavi", "9494827633", "Sanga", "Sanga@abc.in"));
		System.out.println("Enter the number of user details to be added");
		int number = sc.nextInt();
		sc.nextLine();
		for (int i = 0; i < number; i++) {
			System.out.println("Enter the user" + (i + 1) + "detail in csv format");
			String st = sc.nextLine();
			String[] str = st.split(",");
			user.add(new User(str[0], str[1], str[2], str[3]));
		}
		System.out.printf("%-20s%-20s%-20s%-20s", "Name : ", "Contact Number : ", "User Name : ", "Email :");
		System.out.println();
		for (int i = 0; i < user.size(); i++) {
			System.out.printf("%-20s%-20s%-20s%-20s", ((User) user.get(i)).getName(), ((User) user.get(i)).getContactNumber(),
					((User) user.get(i)).getUserName(), ((User) user.get(i)).getEmail());
			System.out.println();
		}
		System.out.println("Enter the range to be removed from the array list");
		int a = sc.nextInt();
		int b = sc.nextInt();
		
		for(int i=a;i<=b;i++) {
			user.remove(i);
		}
		// user.removeRange(a,b);
		System.out.printf("%-20s%-20s%-20s%-20s", "Name : ", "Contact Number : ", "User Name : ", "Email :");
		System.out.println();
		for (int i = 0; i < user.size(); i++) {
			System.out.printf("%-20s%-20s%-20s%-20s", ((User) user.get(i)).getName(), ((User) user.get(i)).getContactNumber(),
					((User) user.get(i)).getUserName(), ((User) user.get(i)).getEmail());
			System.out.println();
		}
	}
}
