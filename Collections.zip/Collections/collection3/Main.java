package com.collection3;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String args[]) {
		ArrayList hall = new ArrayList();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of halls :");
		int number = sc.nextInt();
		sc.nextLine();
		for (int i = 0; i < number; i++) {
			System.out.println("Enter the Hall Name :");
			String name = sc.nextLine();
			hall.add(name);
		}
		System.out.println("Enter the Hall name to be searched :");
		String search = sc.nextLine();
		int pos = hall.indexOf(search);

		if (hall.contains(search)) {
			System.out.println(hall.get(pos) + " Hall is found in the list at the position :" + pos);

		} else
			System.out.println("The hall is not found");

	}
}
