package collections.hcl8;

import java.util.Comparator;

public class TicketBooking implements Comparator<TicketBooking>{
	private String customerName;
	private int Price;

	public TicketBooking() {

	}

	public TicketBooking(String customerName, int Price) {
		super();
		this.customerName = customerName;
		this.Price = Price;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getPrice() {
		return Price;
	}

	public void setPrice(int price) {
		this.Price = price;
	}

	@Override
	public int compare(TicketBooking tb1, TicketBooking tb2) {
		
		if(tb1.Price>tb2.Price) {
			return 1;
		}
		else if (tb1.Price<tb2.Price) {
			return -1;
		}
		else			
			return 0;
	}

}
