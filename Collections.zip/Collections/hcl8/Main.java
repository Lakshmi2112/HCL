package collections.hcl8;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class Main {
	public static void main(String args[]) {
		Scanner sc= new Scanner (System.in);
		ArrayList<TicketBooking> al = new ArrayList <TicketBooking>();
		
		System.out.println(" Enter the number of customers ");
		int number = Integer.parseInt(sc.nextLine());
		sc.nextLine();
		
		for(int i=0;i<number ;i++) {
			//i++;
			TicketBooking tb = new TicketBooking();
			System.out.println("Enter the booking price accordingly with customer name in CSV(Customer Name,Price");
			String st = sc.nextLine();
			//if (i>0) {
			String[] str = st.split(",");
			tb.setCustomerName(str[0]);
			tb.setPrice(Integer.parseInt(str[1]));
			
			al.add(tb);
		}
		//Comparator comp = new TicketBooking();
		TicketBooking tb1 = Collections.min(al, new TicketBooking());
		System.out.println( tb1.getCustomerName() +" spends minimum amount of Rs. " +tb1.getPrice());
		TicketBooking tb2 = Collections.max(al, new TicketBooking());
		System.out.println( tb2.getCustomerName()+" spends maximum amount of Rs." +tb2.getPrice());
	}
}


