package collections.hcl6;

import java.util.HashSet;
import java.util.Scanner;

public class Main {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		HashSet<String> hs = new HashSet<String>();
		System.out.println("Enter username : ");
		String name = sc.nextLine();
		hs.add(name);
		while (true) {
			System.out.println("Do you want to continue ?(yes/no)");
			String choice = sc.nextLine();
			
			if (choice.equals("yes")) {
				
				System.out.println("Enter username ");
				String name1 = sc.nextLine();
				hs.add(name1);
				} 
			else
				break;
		}
		int size = hs.size();
		System.out.println("The unique no. of username is/are" +size);
	}
	
	
}
