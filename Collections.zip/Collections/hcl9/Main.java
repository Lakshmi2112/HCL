package collections.hcl9;

import java.text.CharacterIterator;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import collections.hcl4.User;

public class Main {
	public static void main(String args[]) {
		ArrayList<Stall> al = new ArrayList<Stall>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of stall details");
		int number = sc.nextInt();
		sc.nextLine();
		for (int i = 0; i < number; i++) {

			System.out.println(" Enter the" + (i + 1) + " stall detail");
			String st = sc.nextLine();

			String[] str = st.split(",");

			al.add(new Stall(str[0], str[1], str[2], str[3]));

		}
		//CharacterIterator itr= new CharacterIterator(al);
		Iterator<Stall> it = al.iterator();
		System.out.printf("%-15s %-20s %-15s %s", "Name", "Detail", "Type", "Owner Name");
		System.out.println();
		while(it.hasNext())
		{
			Stall stall = it.next();
			if (stall.getName().startsWith("test")) {
				it.remove();
			}
			else {
				System.out.printf("%-20s%-20s%-20s%-20s", stall.getName(), stall.getDetail(), stall.getType(), stall.getOwnerName());
				System.out.println();
			}
		}
	}
}



