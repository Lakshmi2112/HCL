package collections.hcl13;
import java.util.Comparator;

public class User implements Comparator<User>{
private String name;
private String mobilenumber;
private String username;
private String pasword;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getMobilenumber() {
	return mobilenumber;
}
public void setMobilenumber(String mobilenumber) {
	this.mobilenumber = mobilenumber;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPasword() {
	return pasword;
}
public void setPasword(String pasword) {
	this.pasword = pasword;
}
public User() {
	
}
public User(String name, String mobilenumber, String username, String pasword) {
	super();
	this.name = name;
	this.mobilenumber = mobilenumber;
	this.username = username;
	this.pasword = pasword;
}
@Override
public int compare(User o1, User o2) {
	// TODO Auto-generated method stub
	return o1.getMobilenumber().compareTo(o2.getMobilenumber());
	}

}
