package collections.hcl13;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
public class Main {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of users:");
		ArrayList<User> users = new ArrayList<User>();
		int n = sc.nextInt();
		sc.nextLine();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the details of User "+ (i+1));
			String line = sc.nextLine();
			String[] parts = line.split(",");
			User user = new User(parts[0], parts[1], parts[2], parts[3]);
			users.add(user);
		}
		Collections.sort(users, new User());
		Collections.reverse(users);
		System.out.printf("%-15s%-15s\n", "Name", "Mobile number");
		for(int i=0;i<n;i++)
		{
			User user = users.get(i);
			System.out.printf("%-15s%-15s\n", user.getName(), user.getMobilenumber());
		}
	}
}