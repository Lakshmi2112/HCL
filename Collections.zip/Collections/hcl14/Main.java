package collections.hcl14;

import java.util.*;

public class Main {
	public static void main(String[] args)
	{
		ArrayList<User> users = new ArrayList<User>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of user details");
		int n = sc.nextInt();
		sc.nextLine();
		for(int i=0;i<n;i++) {
			System.out.println("Enter the user "+(i+1)+ " detail");
			String line = sc.nextLine();
			String[] parts =line.split(",");
			User user = new User(parts[0], parts[1], parts[2], parts[3]);
			users.add(user);
		}
		//Collections.sort(users, new SortBy());
		System.out.println("Seach by\n1.Name\n2.Email");
		int c = sc.nextInt();
		sc.nextLine();
		switch(c)
		{
		case 1: System.out.println("Enter the name");
				String name = sc.nextLine();
				int ind = Collections.binarySearch(users, new User(name, null, null, null), new SortByName());
				users.get(ind).print();
				break;
		case 2:  System.out.println("Enter the email");
				String email = sc.nextLine();
				int ind2 = Collections.binarySearch(users, new User(null, email, null, null), new SortByEmail());
				users.get(ind2).print();
				break;
		}
	}
}
