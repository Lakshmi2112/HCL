package collections.hcl10;

import java.util.*;


public class Main {
	public static void main(String[] args)
	{
		ArrayList<Address> addresses = new ArrayList<Address>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of users:");
		int n = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter user address in CSV(Username,AddressLine 1,AddressLine 2,PinCode)");
		
		for(int i=0;i<n;i++)
		{
			String line = sc.nextLine();
			String[] parts = line.split(",");
			Address address = new Address(parts[0], parts[1], parts[2], Integer.parseInt(parts[3]));
			addresses.add(address);
		}
		System.out.println("User Details:");
		Collections.sort(addresses, new Address());
		for(int i=0;i<n;i++)
		{
			Address a = addresses.get(i);
			System.out.println(a.getUsername()+","+a.getAddressLine1()+","+a.getAddressLine2()+","+a.getPinCode());
		}	
	}
}
