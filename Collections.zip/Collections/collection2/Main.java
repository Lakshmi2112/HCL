package com.collection2;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
public static void main(String args[]) {
	
		Scanner sc= new Scanner(System.in);
		ArrayList <ItemType> it = new ArrayList<ItemType>();
		
		
		String choice = "Y";
		while(choice.equals("Y")){
			ItemType it1= new ItemType();
			System.out.println("Enter the details of the Item Type" );
			System.out.println("Name : " );
			String name= sc.nextLine();
			it1.setName(name);
			System.out.println("Deposit : " );
			int deposit= sc.nextInt();
			sc.nextLine();
			it1.setDeposit(deposit);
			System.out.println("Cost Per day: " );
			int costPerDay= sc.nextInt();
			sc.nextLine();
			it1.setCostPerDay(costPerDay);
			it.add(it1);
			System.out.println("Do you want to continue (Y/N)");
			choice = sc.nextLine();
			
		}
		
		System.out.println("The item list is/are : ");
		for (int i = 0; i < it.size(); i++) {
			System.out.println(String.format("%-20s %-20s %-20s" ,"Name : "+it.get(i).getName(),"Deposit : " +it.get(i).getDeposit(),"Cost Per day :" +it.get(i).getCostPerDay()));
		  
		}
	}
}







	 

