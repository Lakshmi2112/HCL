package collections.hcl7;
import java.util.Comparator;

public class Hall implements Comparator<Hall>{
private String name;
private String contactNumber;
private double costPerDay;
private String ownerName;
public Hall() {
	
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getContactNumber() {
	return contactNumber;
}
public void setContactNumber(String contactNumber) {
	this.contactNumber = contactNumber;
}
public double getCostPerDay() {
	return costPerDay;
}
public void setCostPerDay(double costPerDay) {
	this.costPerDay = costPerDay;
}
public String getOwnerName() {
	return ownerName;
}
public void setOwnerName(String ownerName) {
	this.ownerName = ownerName;
}
public Hall(String name, String contactNumber, double costPerDay, String ownerName) {
	super();
	this.name = name;
	this.contactNumber = contactNumber;
	this.costPerDay = costPerDay;
	this.ownerName = ownerName;
}
@Override
public int compare(Hall o1, Hall o2) {
	// TODO Auto-generated method stub
	if(o1.getCostPerDay() < o2.getCostPerDay())
		return -1;
	else 
		return 1;
	
}

}
