package collections.hcl7;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		ArrayList<Hall> halls = new ArrayList<Hall>();
		System.out.println("Enter the number of halls:");
		int n = sc.nextInt();
		sc.nextLine();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the details of hall " + (i+1));
			String line = sc.nextLine();
			String[] parts = line.split(",");
			Hall hall = new Hall(parts[0], parts[1], Double.parseDouble(parts[2]), parts[3]);
			halls.add(hall);
		}
		Collections.sort(halls, new Hall());
		System.out.printf("%-15s%-15s%-15s%-15s\n", "Name", "Contact number", "Cost per day", "Owner name");
		for(int i=0;i<n;i++)
		{
			Hall hall = halls.get(i);
			System.out.printf("%-15s%-15s%-15s%-15s\n", hall.getName(),hall.getContactNumber(), hall.getCostPerDay(), hall.getOwnerName() );
		}
	}
}