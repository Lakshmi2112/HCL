package collection.hcl5;

import java.util.HashSet;
import java.util.Scanner;

public class Main {
	public static void main(String args[]) {
		HashSet<String> hashSet = new HashSet<String>();
		Scanner sc = new Scanner(System.in);
		int i = 0;
		while (true) {
			i++;
			System.out.println("Enter the username " + (i));
			String name = sc.nextLine();
			hashSet.add(name);
			System.out.println("Do You want to contine? (Y/N)");
			String choice = sc.nextLine();
			if (choice.equals("Y")) {
			} 
			else if(hashSet.contains(name)==true) {
				
				System.out.println("The unique number of usernames is " +hashSet.size());
		     break;
		}	
		}
	}
}
