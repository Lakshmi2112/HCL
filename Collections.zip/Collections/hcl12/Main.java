package collections.hcl12;
import java.util.Scanner;
import java.util.ArrayList;
public class Main {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		ArrayList<ArrayList<Integer>> tickets = new ArrayList<ArrayList<Integer>>();
		System.out.println("Enter the count of booked tickets");
		for(int i=0;i<5;i++)
		{
			System.out.println("On Day " + (i+1));
			String line = sc.nextLine();
			String[] parts = line.split(",");
			ArrayList<Integer> dayTickets = new ArrayList<Integer>();
			dayTickets.add(Integer.parseInt(parts[0]));
			dayTickets.add(Integer.parseInt(parts[1]));
			dayTickets.add(Integer.parseInt(parts[2]));
			dayTickets.add(Integer.parseInt(parts[3]));
			tickets.add(dayTickets);
		}
		char c = 'y';
		while(c =='y')
		{
			System.out.println("Enter the day to know its remaining ticket count");
			int day = sc.nextInt();
			sc.nextLine();
			ArrayList<Integer> dayTickets = tickets.get(day -1);
			System.out.print("Remaining tickets:[");
			for(int i=0;i<dayTickets.size();i++)
			{
				if(i == dayTickets.size() - 1)
					System.out.print(100 - dayTickets.get(i));
				else
					System.out.print((100-dayTickets.get(i))+", ");				
			}
			System.out.println("]");
			System.out.println("Do you want to continue? (y/n)");
			c = sc.nextLine().charAt(0);
		}
	}
}
