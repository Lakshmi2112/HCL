package collections.hcl11;
import java.util.Scanner;
import java.util.Collections;
import java.util.ArrayList;

public class Main {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of user detials");
		int n = sc.nextInt();
		sc.nextLine();
		ArrayList<User> users = new ArrayList<User>();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the user "+ (i+1) + " details");
			String line= sc.nextLine();
			String[] parts = line.split(",");
			User user = new User(parts[0], parts[1], parts[2], parts[3]);
			users.add(user);
		}
		System.out.println("Sort by\n1. Name\n2. Email");
		int choice = sc.nextInt();
		sc.nextLine();
		switch(choice)
		{
			case 1:	Collections.sort(users, new NameComparator());
					break;
			case 2: Collections.sort(users, new EmailComparator());
					break;
					
			default: break;
		}
		System.out.printf("%-15s %-15s %-15s %s\n", "Name", "Email", "Username", "Password");
		for(int i=0;i<n;i++)
		{
			User user = users.get(i);
			System.out.printf("%-15s %-15s %-15s %s\n", user.getName(), user.getEmail(), user.getUsername(), user.getPassword());
		}
	}
}


