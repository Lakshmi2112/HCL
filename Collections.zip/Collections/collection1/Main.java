package com.collection1;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;

public class Main {
public static void main(String args[]) {
Scanner sc = new Scanner (System.in);

ArrayList <String >a =new ArrayList<String> ();

int i =0;	
while(true) {
	i++;
System.out.println("Enter the username " + (i) );
String name = sc.nextLine();
a.add(name);
System.out.println("Do You want to contine? (Y/N)");
	String choice= sc.nextLine();
if(choice.equals("N")){
 
System.out.println("The names entered are: " );
for (int i1 = 0; i1 < a.size(); i1++)
{
	System.out.println(a.get(i1));
	
}

break;
}
	
	
	
}
}
}
