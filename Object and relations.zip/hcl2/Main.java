package com.hcl2;

import java.util.Scanner;



public class Main {
      public static void main(String args[]) {
    	  System.out.println("Reading products");
  	
  		
  			Products p1 = buildProducts();
  		
  			Products p2 = buildProducts();
  		
  			System.out.println("Products details: ");
  			System.out.println();
  			System.out.println("L & K SUPPLIERS");
  			System.out.println("Product Code: "+p1.getProduct_code());
  			System.out.println("Name: "+p1.getProduct_name());
  			System.out.println("Stock: "+p1.getStock());
  			System.out.println("Price: "+p1.getPrice());
  			System.out.println("Discounted Price: "+p1.getDiscountedPrice(p1));
  			System.out.println();

  			System.out.println("L & K SUPPLIERS");	
  			System.out.println("Product Code: "+p2.getProduct_code());
  			System.out.println("Name: "+p2.getProduct_name());
  			System.out.println("Stock: "+p2.getStock());
  			System.out.println("Price: "+p2.getPrice());
  			System.out.println("Discounted Price: "+p2.getDiscountedPrice(p2));
  			System.out.println();
  			System.out.println(Products.checkPrice(p1, p2));


      }
	

  static Products buildProducts() {
		Scanner sc=new Scanner(System.in);
		Products p1= new Products();
	
		System.out.println("Enter the product code");
		p1.setProduct_code(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter the product name");
		p1.setProduct_name(sc.nextLine());
		System.out.println("Enter the price");
		p1.setPrice(sc.nextDouble());
		System.out.println("Enter the Stock");
		p1.setStock(sc.nextInt());
		p1.setStatic_name((" L & K Suppliers"));
		return p1;
		
	}
	
}
	
	

	
	
	
	
	
	
	
	
	
	


