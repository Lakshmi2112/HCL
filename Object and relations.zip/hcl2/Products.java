package com.hcl2;

public class Products {

private int product_code;
private String product_name;
private double price;
private int stock;
private String static_name;

public Products() {
	
}
public Products(int product_code, String product_name, double price, int stock, String static_name) {
	super();
	this.product_code = product_code;
	this.product_name = product_name;
	this.price = price;
	this.stock = stock;
	this.static_name = static_name;
}
public int getProduct_code() {
	return product_code;
}
public void setProduct_code(int product_code) {
	this.product_code = product_code;
}
public String getProduct_name() {
	return product_name;
}
public void setProduct_name(String product_name) {
	this.product_name = product_name;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public int getStock() {
	return stock;
}
public void setStock(int stock) {
	this.stock = stock;
}
public String getStatic_name() {
	return static_name;
}
public void setStatic_name(String static_name) {
	this.static_name = static_name;
}
public double getDiscountedPrice(Products pr)
{
	if(pr.price>=80000) {
		return pr.price*(0.3);		
	}
	else if(pr.price>=60000) {
		return pr.price*(0.2);				
	}
	else if(pr.price>=50000) {
		return pr.price*(0.1);				
	}
	else {
		return pr.price*(0.05);	
	}			
}
public static String checkPrice(Products p1, Products p2) {
	if(p1.price==p2.price) {
		return p1.product_name + " and " + p2.product_name + " are in same price";
	}
	
	else if(p1.price>p2.price) {
		return p2.product_name + " is cheaper than " + p1.product_name;
	}
	
	else {
		return p1.product_name + " is cheaper than " + p2.product_name;
	}
}

}


































/*void DiscountedPrice() {
	if(Products.setPrice>=80000) {
		double DiscountedPrice = ((Products.setPrice*(30/100)));
		
	}
	else if(Products.setPrice>=60000) {
		double DiscountedPrice = ((Products.setPrice*(20/100)));
		
	}
	else if(Products.setPrice>=50000) {
		double DiscountedPrice = ((Products.setPrice*(10/100)));
	
}
	else {
		double DiscountedPrice = ((Products.setPrice*(5/100)));
}
	System.out.println("Discounted price" +DiscountedPrice);
}
 static void checkPrice(Products pc1,Products pc2){
	if(pc1.getPrice()==pc2.getPrice()) {
		System.out.println("The cost of 2 products are same");
		
	}
	 if(pc1.getPrice()>pc2.getPrice()) {
		System.out.println(pc2.getProduct_name()+"is cheaper");
		
	}
	else {
		System.out.println(pc1.getProduct_name()+"is cheaper");
		
	}
}
 void Display() {
	System.out.println(static_name);
	System.out.println("Product code:" +product_code);
	System.out.println("Product name:" +product_name);
	System.out.println("Price:" +price);
	System.out.println("Stock: " +stock);
	System.out.println("Discounted Price:" +DiscountedPrice);
	
	}*/

