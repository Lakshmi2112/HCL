package com.hcl6;

public class Songs {
	
		public int id, film_id;
		public String Name, Singer;
		Songs(int id, String Name, String Singer, int film_id)
		{
			this.id = id;
			this.Name = Name;
			this.Singer = Singer;
			this.film_id = film_id;
		}
	
}
