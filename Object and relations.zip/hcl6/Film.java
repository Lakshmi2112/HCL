package com.hcl6;

public class Film {
	
		public int id;
		public String Name;
		Film()
		{
		}
		Film(int id, String name)
		{
			this.id = id;
			this.Name = name;
		}
	/*	public int getFilId(String filmName, Film obj[])
		{
			for(int i = 0;i < obj.length; i++)
			{
				if(obj[i].Name == filmName)
				{
					return obj[i].id;
				}
			}
			return -1;
		}*/
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
	}

