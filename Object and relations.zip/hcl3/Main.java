package com.hcl3;

import java.util.Scanner;



public class Main {
	
	private static int items = 2;
	
	public static void main (String[]args) {
		
		Scanner sc=new Scanner(System.in);
		Item[] itemArray = new Item[items];
		
		System.out.println("Reading products");
		for(int i=0;i<items;i++)
		{
			Item item = buildProduct();
			itemArray[i] = item;
		}
		System.out.println("Displaying prodcuts");
		for(int i =0;i<items;i++)
		{
			Item item = itemArray[i];
			displayProduct(item);
		}
		System.out.println("Calculating discout");
		for(int i=0;i<items;i++)
		{			
			System.out.println("Discounted price for " + itemArray[i].getProduct_name() + " is " + itemArray[i].getDiscountedPrice());
		}
		System.out.println("check less stock");
		System.out.println(Item.checkLessStock(itemArray).getProduct_name() + " has the minimum stock");
	}
	
	public static void displayProduct(Item it)
	{
		System.out.println("Product code: " + it.getProduct_code());
		System.out.println("Product Name: " +it.getProduct_name());
		System.out.println("Price: " + it.getPrice());
		System.out.println("Stock: " + it.getStock());
	}
	
	public static Item buildProduct() {
		Scanner sc=new Scanner(System.in);
		Item item = new Item();
		System.out.println("Product code:");
		item.setProduct_code(sc.nextInt());
		sc.nextLine();
		System.out.println("Product name:");
		item.setProduct_name(sc.nextLine());
		System.out.println("Product price:");
		item.setPrice(sc.nextDouble());
		System.out.println("Product stock:");
		item.setStock(sc.nextInt());
		
		return item;
	}
	

}
  
