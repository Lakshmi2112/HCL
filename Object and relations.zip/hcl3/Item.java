package com.hcl3;



public class Item {
	private int product_code;
	private String product_name;
	private double Price;
	private int Stock;
	private static String name;
	
	public Item() {
		
	}
	
	public Item(int product_code, String product_name, double price, int stock) {
		super();
		this.product_code = product_code;
		this.product_name = product_name;
		Price = price;
		Stock = stock;
	}

	public int getProduct_code() {
		return product_code;
	}

	public void setProduct_code(int product_code) {
		this.product_code = product_code;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public double getPrice() {
		return Price;
	}

	public void setPrice(double price) {
		Price = price;
	}

	public int getStock() {
		return Stock;
	}

	public void setStock(int stock) {
		Stock = stock;
	}

	public static String getName() {
		return name;
	}

	public static void setName(String name) {
		Item.name = name;
	}
	
	public double getDiscountedPrice()
	{
		if(Price>=80000) {
			return (double)((Price * 30)/100);		
		}
		else if(Price>=60000) {
			return (double)((Price * 20)/100);				
		}
		else if(Price>=50000) {
			return (double)((Price * 10)/100);				
		}
		else {
			return (double)((Price * 5)/100);	
		}			
	}
	public static Item checkLessStock(Item[] itemArray) {
		int minStock = 9999999;
		Item item = new Item();
		for(int i=0;i<itemArray.length;i++)
		{
			if(itemArray[i].getStock() < minStock)
			{
				minStock = itemArray[i].getStock();
				item = itemArray[i];
			}
		}
		return item;
	}
	
	
	public static String checkPrice(Item item1, Item item2)
	{
		if(item1.getPrice() < item2.getPrice())
			return item1.getProduct_name() + " is cheaper.";
		else
			return item2.getProduct_name() + " is cheaper.";
	}
}


