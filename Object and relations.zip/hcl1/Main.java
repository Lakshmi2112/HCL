package com.hcl1;

import java.util.Scanner;

public class Main {
	public static void main(String args[]) {
		Scanner sc= new Scanner(System.in);
		Product pc1=new Product();
		Product pc2=new Product();
	    System.out.println("First Product");	
	    System.out.println("Product Code");
        pc1.setProduct_Code(sc.nextInt());
        System.out.println("Product Name");
        sc.nextLine();
        pc1.setProduct_name(sc.nextLine());
        System.out.println("Price");
        pc1.setPrice(sc.nextDouble());
        System.out.println("Stock");
        pc1.setStock(sc.nextInt());
	    System.out.println("Second Product");
        System.out.println("Product Code");
        pc2.setProduct_Code(sc.nextInt());
        System.out.println("Product Name");
        sc.nextLine();
        pc2.setProduct_name(sc.nextLine());
        System.out.println("Price");
        pc2.setPrice(sc.nextDouble());
        System.out.println("Stock");
        pc2.setStock(sc.nextInt());
	    System.out.println("Product Details:" +"\n" + "Product Code:" +pc1.getProduct_Code()+"\n" 
        + "Product name:" +pc1.getProduct_name()+"\n" + "Price:" +pc1.getPrice()+ "\n"+"Stock:" +pc1.getStock()+"\n" + "Product Code:" +pc2.getProduct_Code()+"\n" 
        + "Product name:" +pc2.getProduct_name()+"\n" + "Price:" +pc2.getPrice()+ "\n"+"Stock:" +pc2.getStock());

		{	
	 Product.checkPrice(pc1,pc2) ;
	     }
     }

}









