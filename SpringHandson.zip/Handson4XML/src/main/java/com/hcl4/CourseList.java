package com.hcl4;

import java.util.ArrayList;

public class CourseList {
	private ArrayList<Course> course = new ArrayList();

	public CourseList() {

	}

	public CourseList(ArrayList<Course> courseList) {
		super();
		this.course = courseList;
	}

	public ArrayList<Course> getCourseList() {
		return course;
	}

	public void setCourseList(ArrayList<Course> courseList) {
		this.course = courseList;
	}

	public void insert(Course Course) {
		course.add(Course);

	}

public double revenue() {
	double revenue=0;
	for(Course courselist :course) {
		revenue+=courselist.getFee()*(0.2*200);
	}
	return revenue;
	
}

}
