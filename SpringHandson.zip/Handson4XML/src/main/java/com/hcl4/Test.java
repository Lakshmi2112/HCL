package com.hcl4;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
public static void main(String[] args) {
	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
	CourseList courselist = new CourseList();
	Course course1= context.getBean("Course1",Course.class);
	Course course2= context.getBean("Course2",Course.class);
	Course course3= context.getBean("Course3",Course.class);
	courselist.insert(course1);
	courselist.insert(course2);
	courselist.insert(course3);

	System.out.println(courselist.revenue());
	((ClassPathXmlApplicationContext) context).close();
}
}
