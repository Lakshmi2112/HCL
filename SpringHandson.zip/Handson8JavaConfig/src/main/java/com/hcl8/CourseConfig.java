package com.hcl8;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CourseConfig {

	@Bean(name="course1")
	public Course getCourse1() {
		Course course1=new Course();
		course1.setName("JAVA Core");
		course1.setMentor("Aishu");
		course1.setFee(2000);
		return course1;
	}
	@Bean(name="course2")
	public Course getCourse2() {
		Course course2=new Course();
		course2.setName("Python");
		course2.setMentor("Nivedha");
		course2.setFee(1000);
		return course2;
	}
	@Bean(name="course3")
	public Course getCourse3() {
		Course course3=new Course();
		course3.setName("Servlets");
		course3.setMentor("Shivani");
		course3.setFee(500);
		return course3;
	}
	
}
