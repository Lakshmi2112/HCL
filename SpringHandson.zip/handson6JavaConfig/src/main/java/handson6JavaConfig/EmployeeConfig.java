package handson6JavaConfig;

import org.springframework.context.annotation.Bean;

public class EmployeeConfig {
	@Bean(name = "Employee")
	public Employee getEmployee() {
		Employee employee1 = new Employee();
		employee1.setEmployeeName("Sathish");
		employee1.setEmployeeSalary("45000");
		employee1.setEmployeeMobileNumber("9484839483");
		employee1.setEmployeeEmail("sathish@gmail.com");
		return employee1;
	}

	@Bean(name = "address")
	public Address getAddress() {
		Address address = new Address();
		address.setLine1("2/115 Anna Nagar");
		address.setLine2("Kaveripattinam");
		address.setCity("Krishnagiri");
		address.setPincode("635112");
		return address;
	}

}
