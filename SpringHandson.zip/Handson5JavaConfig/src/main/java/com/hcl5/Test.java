package com.hcl5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {
	public static void main(String[] args) throws IOException {
		ApplicationContext context = new AnnotationConfigApplicationContext(ConfigJavaFile.class);
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		Owner owner = context.getBean("owner", Owner.class);
		System.out.println("Enter the name,password,mobile number of the user");
		String name = reader.readLine();
		String password = reader.readLine();
		String mobileNumber = reader.readLine();
		owner.setName(name);
		owner.setPassword(password);
		owner.setMobileNumber(mobileNumber);
		owner.display();

	}
}
