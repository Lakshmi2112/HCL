package com.hcl5;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Bean;

@Configurable
public class ConfigJavaFile {
 @Bean(name = "owner")
 public Owner getOwner() {
	return new Owner();
	 
 }
 
}
