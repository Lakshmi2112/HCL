package com.hcl5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
public static void main(String[]args) throws IOException {
	ApplicationContext context = new ClassPathXmlApplicationContext("apllicationContext.xml");
	BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter the Name,Password,Mobile Number");
	String Name = reader.readLine();
	String Password = reader.readLine();
	String MobileNumber = reader.readLine();
	Owner owner = (Owner) context.getBean(Owner.class);
	owner.setDetails(Name, Password, MobileNumber);
	
	owner.display();
	
	
}
}
