package com.hcl3;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration

public class CourseConfig {
	@Bean(name = "Course1")
	public Course getCourse1() {
		Course course = new Course();
		course.setName("java");
		course.setMentor("Sathish");
		course.setFee(1000.0);
		return course;
	}
	@Bean(name = "Course2")
	public Course getCourse2() {
		Course course = new Course();
		course.setName("java");
		course.setMentor("Sathish");
		course.setFee(2000.0);
		return course;
	}
	@Bean(name = "Course3")
	public Course getCourse3() {
		Course course = new Course();
		course.setName("java");
		course.setMentor("Sathish");
		course.setFee(500.0);
		return course;
	}

}
