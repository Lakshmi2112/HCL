package com.hcl3;

import java.util.ArrayList;

public class CourseList {
	private ArrayList<Course> courseList = new ArrayList();

	public CourseList() {

	}

	public CourseList(ArrayList<Course> courseList) {
		super();
		this.courseList = courseList;
	}

	public ArrayList<Course> getCourseList() {
		return courseList;
	}

	public void setCourseList(ArrayList<Course> courseList) {
		this.courseList = courseList;
	}

	public void insert(Course Course) {
		courseList.add(Course);

	}

	public void discount() {
		double highest = 0;
		double lowest = 9999999;
		String highestName = null;
		String lowestName = null;
		for (Course course : courseList) {
			if (course.getFee() > highest) {
				highest = course.getFee();
				highestName = course.getName();
			} else if (course.getFee() < lowest) {
				lowest = course.getFee();
				lowestName = course.getName();
			}

		}
		System.out.println("The discount price for " + highestName + "is " + (0.1 * highest));
		System.out.println("The discount price for " + lowestName + "is " + (0.05 * lowest));
	}

}
