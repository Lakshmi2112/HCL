package com.hcl7;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OrderConfig {

	@Bean(name="user")
			public User getUser() {
		User user1=new User();
		user1.setName("Jagan");
		user1.setAge(24);
		user1.setCity("Chennai");
		return user1;
	}
	
	@Bean(name="orderOne")
	public Order getOrder() {
		Order order1=new Order();
		order1.setItemName("Iphone5s");
		order1.setPrice(4000);
		return order1;
	}
	
	@Bean(name="orderTwo")
	public Order getOrder1() {
		Order order2=new Order();
		order2.setItemName("Iphone6s");
		order2.setPrice(60000);
		return order2;
	}
	
}
