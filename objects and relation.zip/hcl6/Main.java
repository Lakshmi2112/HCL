package com.hcl6;

import java.util.Scanner;

public class Main {
	
		public static void main(String args[])
		{
			Scanner sc = new Scanner(System.in);
			System.out.println("How many films?");
			int filmsCount = sc.nextInt();
			int totalSongsCount = 0;
			Film[] fobj =new Film[filmsCount];
			Songs[] sobj = new Songs[1000];
			for(int i = 0; i < filmsCount;i++)
			{
				System.out.println("Enter Film Details: (id, name)");
				String[] FilmDetails = (sc.nextLine()).split(", ");
				fobj[i] = new Film(Integer.parseInt(FilmDetails[0]), FilmDetails[1]);
				System.out.println("How many songs in	"+FilmDetails[1]);
				int songsCount = sc.nextInt();
				for(int j = totalSongsCount; j < (songsCount+totalSongsCount); j++)
				{
					System.out.println("Enter song details: (id: name: singers)");
					String[] SongDetails = (sc.nextLine()).split(": ");
					sobj[j] = new Songs(Integer.parseInt(SongDetails[0]), SongDetails[1], SongDetails[2], Integer.parseInt(FilmDetails[0]));
				}
				totalSongsCount+=songsCount;
			}
			System.out.println("Enter Film Name:");
			String inputFilmName = sc.nextLine();
			Film f = new Film();
			//int inputFilmId = f.getFilId(inputFilmName, fobj);
			int inputFilmId = f.getId();
			System.out.println("Songs of film: "+inputFilmName);
			for(int i = 0; i < totalSongsCount; i++)
			{
				if(sobj[i].film_id == inputFilmId)
				{
					System.out.println("Song Name: "+sobj[i].Name);
					System.out.println("Singer: "+sobj[i].Singer);
				}
			}
		}
	}

