package com.hcl1;

public class Product {
 public static Product pc1;
public static Product pc2;
int Product_Code;
String Product_name;
double price;
int stock;
public Product(){
	
}
public Product(int producut_Code, String product_name, double price, int stock) {
	super();
	Product_Code = producut_Code;
	Product_name = product_name;
	this.price = price;
	this.stock = stock;
}
public int getProduct_Code() {
	return Product_Code;
}
public void setProduct_Code(int producut_Code) {
	Product_Code = producut_Code;
}
public String getProduct_name() {
	return Product_name;
}
public void setProduct_name(String product_name) {
	Product_name = product_name;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public int getStock() {
	return stock;
}
public void setStock(int stock) {
	this.stock = stock;
}
public static void checkPrice(Product pc1,Product pc2) {
	if(pc1.price==pc2.price) {
		 System.out.println(pc1.Product_name+ "and" +pc2.Product_name+ "are equal");
		 }
	else if (pc1.price > pc2.price) {
		 System.out.println( pc2.Product_name+ " is cheaper");
	}
	else  {
		 System.out.println( pc1.Product_name+ " is cheaper");
	}
  }
public String getDiscountedPrice1() {
	// TODO Auto-generated method stub
	return null;
}
public String getDiscountedPrice() {
	// TODO Auto-generated method stub
	return null;
}


}
