package com.hclServlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/index")
public class SecondServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public SecondServlet() {
    super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		
		PrintWriter pw = response.getWriter();
		
		pw.write("<h1 Style = \"text-align:center; color :pink ; \"> Welcome to Hall Paradise </h1>");
		pw.write("<p Style = \"text-align: center ; \" > The type of events are   </p>");
		pw.write("<ul type = bulletin ; Style= \" padding-left:43% ; \" >  ");
		pw.write("<li > Exhibition </li>");
		pw.write("<li > Stage Show </li>");
		pw.write("</ul>");
		pw.close();
	}

}

