package com.hcl4;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/FourthServlet")
public class FourthServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public FourthServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		pw.write("<form action = \"./Validate\" method =\"Post\">");
		pw.write("Event name<input type  = \" text\" ; name = \"eventname\">");
		pw.write("</br>");
		pw.write("Hall name<input type  = \" text\" ; name = \"hallname\">");
		pw.write("</br>");
		pw.write("EventType<input type=\"radio\" value=\"Exhibition\" name=\"eventtype\">Exhibition<br>");

		pw.write("<input type=\"radio\" value=\"StageShow\" name=\"eventtype\">StageShow<br>");

		pw.write("Details<input type  = \" text\" ; name = \"details\">");
		pw.write("</br>");

		pw.write("Owner <input type  = \" text\" ; name = \"owner\">");
		pw.write("</br>");

		pw.write("Start Date<input type=\"text\" name=\"startdate\"><br>");
		pw.write("End Date<input type=\"text\" name=\"enddate\"><br>");

		pw.write("<input type=\"submit\" value=\"Create\">");
		pw.write("</form>");
		pw.close();

	}

}
