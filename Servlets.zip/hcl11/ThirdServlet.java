package com.hcl11;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ThirdServlet")
public class ThirdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public ThirdServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	response.setContentType("text/html");
	PrintWriter pw = response.getWriter();
	pw.write(" <h1 style = \"text-align : center  \"> User Details </h1>");
	
	pw.write("<div style = \"text-align: center\" >");
	pw.write("<div style= \"padding: 15px \">");
	pw.write("<div style=  \"width : 100%; \">");
	pw.write("<form action=\"./ThirdServletDisplay\"method= \"post\">");
	pw.write("<label for=\"name\"><b> Name : </b></label>");
	pw.write("<input type=\"text\"name=\"name\" required>");
	pw.write("<br>");
	pw.write("<label for=\"phoneNumber\"><b> Phone Number : </b></label>");
	pw.write("<input type=\"text\"name=\"phoneNumber\" required>");
	pw.write("<br>");
	pw.write("<label for=\"email\"><b> Email : </b></label>");
	pw.write("<input type=\"text\"name=\"email\" required>");
	pw.write("<br>");
	pw.write("<label for=\"name\"><b> City : </b></label>");
	pw.write("<input type=\"text\"name=\"city\" required>");
	pw.write("<br>");
	pw.write("<button> Submit </submit> ");
	pw.write("</form>");
	pw.close();
	}


}








